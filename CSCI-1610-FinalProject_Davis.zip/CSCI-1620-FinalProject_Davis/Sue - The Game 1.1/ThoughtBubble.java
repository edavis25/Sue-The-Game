import greenfoot.*;

/**
 * Thought Bubble  - This is pretty much just part of the background. 
 * 
 * @author Eric Davis
 * @version Version 1.0
 */
public class ThoughtBubble extends Actor
{
                
    /**
     * Act - do whatever the ThoughtBubble wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
         
    }    
      
    
}
