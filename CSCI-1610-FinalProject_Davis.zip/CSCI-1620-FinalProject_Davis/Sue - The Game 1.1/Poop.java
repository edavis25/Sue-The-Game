import greenfoot.*;

/**
 * Poop  - Gross!
 * 
 * @author Eric Davis
 * @version Version 1.0
 */
public class Poop extends Actor
{
    /**
     * Act - do whatever the Poop wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
