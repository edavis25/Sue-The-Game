import greenfoot.*;

/**
 * Bush - Doesn't do much. Squirrels will use these as a place to hide.
 * 
 * @author Eric Davis
 * @version Version 1.0
 */
public class Bush extends Actor
{
    /**
     * Act - do whatever the Bush wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
